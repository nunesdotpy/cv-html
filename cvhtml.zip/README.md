# Curriculum Vitae

## Made with HTML5 and CSS3

Avaible on http://cv.nunesdotpy.tech as well